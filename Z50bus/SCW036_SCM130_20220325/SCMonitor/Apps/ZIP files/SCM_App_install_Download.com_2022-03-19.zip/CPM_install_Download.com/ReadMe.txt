Install DOWNLOAD.COM to compact flash

This program is for the Z50Bus and RC2014.

This program is written as an App for the Small Computer Monitor v1.x

It is used to install DOWNLOAD.COM on to a formatted Compact Flash 
card containing CP/M 2.2.

SCM_Install_Download_code8000.hex is a universal Z80/Z180 version but it 
does write to more I/O addresses as a result, which could be an issue.
Other versions are in the "Others" folder.

The code loads and runs from the indicated code address.

Send the hex file to the Small Computer Monitor using a terminal program.

Start the program with the SCMonitor command "G 8000"

Following the instructions displayed on the terminal.

LiNC80 version written by Jon Langseth


SCC 2022-03-17