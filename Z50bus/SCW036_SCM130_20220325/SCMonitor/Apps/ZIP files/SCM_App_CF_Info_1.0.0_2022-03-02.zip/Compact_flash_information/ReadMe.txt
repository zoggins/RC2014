Compact Flash Information

This program is written as an App for the Small Computer Monitor v1.0

This program reads identification information from a Compact Flash card 
and displays the results. It also executes the Compact Flash's internal 
diagnostics. 

The program implements the recommended status checks and also test for 
errors reported by the Compact Flash card. As a result it should be
reliable. It is also informative if problems are detected.

Compact Flash cards in binary multiples from 1MB to 2TB should be 
correctly identified and described. So 1MB, 2MB, 4MB, 8MB, 16MB, 32MB, 
64MB should be correct, but a 48MB card will likely be reported as 32MB. 
It was much easier to deal with just the binary multiples than all 
possible sizes, so I took the easy way out. My bad!

Compatible with LiNC80, Z50Bus, and RC2014 systems.

The hex files can be download to SCM by using a terminal program's
"Send file" feature to send a .HEX file to SCM.

There are several versions of the .HEX file:
SCM_CF_Info_Z80_CFx10_code8000.hex
SCM_CF_Info_Z80_CFx90_code8000.hex
SCM_CF_Info_Z280RC_CFxC0_code8000.hex

The filename indicates the hardware it is designed for:
The processor or system is either Z80 or Z280RC
The compact flash base I/O address is typically 0x10 or 0x90
The code loads and runs from the indicates code address

Typically the program is started with the SCM command "G 8000"


SCC 2022-03-02

