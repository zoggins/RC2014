Install DOWNLOAD.COM to compact flash

This program is for the LiNC80, Z50Bus, and RC2014.

This program is written as an App for the Small Computer Monitor v1.0

It is used to install DOWNLOAD.COM on to a formatted Compact Flash 
card containing CP/M.

Send the hex file to the Small Computer Monitor using a terminal program.

Start the program with the SCMonitor command "G 8000"

Following the instructions displayed on the terminal.

LiNC80 version written by Jon Langseth
