Contribution from Ivan De La Fuente - 2020-12-03

Adds Z180 instructions to SCM's assemble/disassemble commands

The file "DisData.asm" replaces
\SCWorkshop\SCMonitor\Source\Monitor\DisData.asm



-----------------------------------------------------------------------------



If the variable PROCESSOR = "Z180" activates the code


New Instructions Operation for z180

SLP Enter SLEEP mode
MLT 8-bit multiply with 16-bit result
INO g, (m) Input contents of immediate I/O address
OUT0 (m), g Output register contents to immediate I/O address
OTIM Block output - increment
OTIMR Block output - increment and repeat
OTDM Block output - decrement
OTDMR Block output - decrement and repeat
TSTIO m Non-destructive AND, I/O port, and accumulator
TST g Non-destructive AND, register, and accumulator
TST m Non-destructive AND, immediate data, and accumulator
TST (HL) Non-destructive AND, memory data, and accumulator

D 76            SLP
ED 38 20         IN0  A,(n)
ED 00 20         IN0  B,(n)
ED 08 20         IN0  C,(n)
ED 10 20         IN0  D,(n)
ED 18 20         IN0  E,(n)
ED 20 20         IN0  H,(n)
ED 28 20         IN0  L,(n)
ED 39 56         OUT0 (imm8),A
ED 01 56         OUT0 (imm8),B
ED 09 56         OUT0 (imm8),C
ED 11 56         OUT0 (imm8),D
ED 19 56         OUT0 (imm8),E
ED 21 56         OUT0 (imm8),H
ED 29 56         OUT0 (imm8),L
ED 74 20        TSTIO n
ED 3C           TST  A
ED 04           TST  B
ED 0C           TST  C
ED 14           TST  D
ED 1C           TST  E
ED 24           TST  H
ED 2C           TST  L
ED 34           TST  (HL)
ED 64 20        TST  n
ED 4C           MLT BC
ED 5C           MLT DE
ED 6C           MLT HL
ED 7C           MLT SP
ED 8B           OTDM
ED 9B           OTDMR
ED BB           OTDR
ED 83           OTIM
ED 93           OTIMR
ED B3           OTIR
