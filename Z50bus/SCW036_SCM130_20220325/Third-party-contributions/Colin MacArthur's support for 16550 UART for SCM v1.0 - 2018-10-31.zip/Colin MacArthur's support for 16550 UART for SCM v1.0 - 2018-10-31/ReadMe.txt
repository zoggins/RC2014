Colin MacArthur's support for 16550 UART for SCM v1.0 - 2018-10-31

See post in rc2014 google group:
https://groups.google.com/g/rc2014-z80/c/vKCQSUEmaTc/m/0z4D8OdrAwAJ
